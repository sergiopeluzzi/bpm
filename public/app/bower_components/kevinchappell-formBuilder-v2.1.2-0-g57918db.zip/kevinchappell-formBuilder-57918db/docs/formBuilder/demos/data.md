# Getting Data

```
var formBuilder = $fbEditor.formBuilder();
var formData = formBuilder.formData; //getter
```

### Get formData using actions:
<p data-height="580" data-theme-id="22927" data-slug-hash="zwrddy" data-default-tab="js,result" data-user="kevinchappell" data-embed-version="2" class="codepen"></p>

### Get formData from `formData`
<p data-height="580" data-theme-id="22927" data-slug-hash="bpRowv" data-default-tab="js,result" data-user="kevinchappell" data-embed-version="2" class="codepen"></p>

### Where's my HTML
There are some cases where you would want the HTML instead of a rendered form.
<p data-height="300" data-theme-id="22927" data-slug-hash="wWvyaM" data-default-tab="result" data-user="kevinchappell" data-embed-version="2" class="codepen"></p>
