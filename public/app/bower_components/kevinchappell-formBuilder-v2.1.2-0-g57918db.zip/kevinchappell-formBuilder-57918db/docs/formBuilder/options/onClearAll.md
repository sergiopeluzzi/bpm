# onClearAll
Callback that executes when fields are cleared.

## Usage
```javascript
var options = {
      onClearAll: function(formData) {
          alert('all fields removed');
        },
    };
$(container).formBuilder(options);
```
## See it in Action
<p data-height="525" data-theme-id="22927" data-embed-version="2" data-slug-hash="vmNaWw" data-default-tab="result" data-user="kevinchappell" class="codepen"></p>
