'use strict';

((window.gitter = {}).chat = {}).options = {
  room: 'kevinchappell/formBuilder'
};
